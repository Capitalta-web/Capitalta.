import PropTypes from 'prop-types';
import { Suspense } from 'react';

// @next
import dynamic from 'next/dynamic';
import { notFound } from 'next/navigation';

// @project
import Loader from '@/components/Loader';

const Translation = dynamic(() => import('@/views/admin/setting/translate'));

/*************************** LANGUAGES - DATA ***************************/

async function getLanguage(language) {
  const res = await ['english', 'spanish', 'danish', 'indonesian'].find((languages) => languages === language);
  return res || null;
}

/*************************** I18N - TRANSLATE LANGUAGE ***************************/

export default async function I18NTranslate({ params }) {
  const { language } = await params;
  const languageData = await getLanguage(language);
  if (!languageData) return notFound();

  return (
    <Suspense fallback={<Loader />}>
      <Translation language={languageData} />
    </Suspense>
  );
}

I18NTranslate.propTypes = { params: PropTypes.object };
