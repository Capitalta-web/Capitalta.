import PropTypes from 'prop-types';
import { Suspense } from 'react';

// @next
import dynamic from 'next/dynamic';

// @project
import Loader from '@/components/Loader';

const PricingPlanEdit = dynamic(() => import('@/views/admin/setting/pricing/plan-edit'));

/*************************** PRICING - PLAN EDIT ***************************/

export default async function EditPricingPlan({ params }) {
  const { id } = await params;

  return (
    <Suspense fallback={<Loader />}>
      <PricingPlanEdit id={id} />
    </Suspense>
  );
}

EditPricingPlan.propTypes = { params: PropTypes.object };
