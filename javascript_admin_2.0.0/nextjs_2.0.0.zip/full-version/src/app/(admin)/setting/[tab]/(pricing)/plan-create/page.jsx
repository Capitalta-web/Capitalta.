// @next
import dynamic from 'next/dynamic';

// @project
const PlanCreate = dynamic(() => import('@/views/admin/setting/pricing/plan-create'));

/***************************  PRICING - PLAN CREATE  ***************************/

export default function CreatePricingPlan() {
  return <PlanCreate />;
}
