// @next
import dynamic from 'next/dynamic';

// @project
const Billing = dynamic(() => import('@/views/admin/billing'));

//***************************  BILLING  ***************************//

export default function Billings() {
  return <Billing />;
}
