// @next
import dynamic from 'next/dynamic';

// @project
const BlogCreate = dynamic(() => import('@/views/admin/blog/blog-create'));

/***************************  BLOGS - CREATE  ***************************/

export default function CreateBlog() {
  return <BlogCreate />;
}
