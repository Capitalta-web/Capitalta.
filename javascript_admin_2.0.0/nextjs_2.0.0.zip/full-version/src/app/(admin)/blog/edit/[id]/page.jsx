import PropTypes from 'prop-types';
import { Suspense } from 'react';

// @next
import dynamic from 'next/dynamic';

// @project
import Loader from '@/components/Loader';

const BlogEdit = dynamic(() => import('@/views/admin/blog/blog-edit'));

/*************************** BLOG - EDIT ***************************/

export default async function EditBlog({ params }) {
  const { id } = await params;

  return (
    <Suspense fallback={<Loader />}>
      <BlogEdit id={id} />
    </Suspense>
  );
}

EditBlog.propTypes = { params: PropTypes.object };
