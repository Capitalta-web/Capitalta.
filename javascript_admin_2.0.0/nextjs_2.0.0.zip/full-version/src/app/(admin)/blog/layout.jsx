import PropTypes from 'prop-types';

// @project
import SWRProvider from '@/sections/blog/api/SWRProvider';

/***************************  LAYOUT - BLOG  ***************************/

export default function BlogLayout({ children }) {
  return <SWRProvider>{children}</SWRProvider>;
}

BlogLayout.propTypes = { children: PropTypes.node };
