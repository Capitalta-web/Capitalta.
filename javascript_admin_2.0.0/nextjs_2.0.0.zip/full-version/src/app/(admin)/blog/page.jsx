// @next
import dynamic from 'next/dynamic';

// @project
const Blog = dynamic(() => import('@/views/admin/blog'));

/***************************  BLOGS  ***************************/

export default function Blogs() {
  return <Blog />;
}
