import PropTypes from 'prop-types';
import { Suspense } from 'react';

// @next
import dynamic from 'next/dynamic';

// @project
import Loader from '@/components/Loader';

const BlogDetail = dynamic(() => import('@/views/admin/blog/blog-detail'));

/*************************** BLOG - DETAIL ***************************/

export default async function DetailBlog({ params }) {
  const { id } = await params;

  return (
    <Suspense fallback={<Loader />}>
      <BlogDetail id={id} />
    </Suspense>
  );
}

DetailBlog.propTypes = { params: PropTypes.object };
