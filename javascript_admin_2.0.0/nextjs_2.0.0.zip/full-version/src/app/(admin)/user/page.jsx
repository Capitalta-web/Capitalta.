// @next
import dynamic from 'next/dynamic';

// @project
const User = dynamic(() => import('@/views/admin/user'));

/***************************  USER  ***************************/

export default function Users() {
  return <User />;
}
