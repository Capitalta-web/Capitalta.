// @next
import dynamic from 'next/dynamic';

// @project
const PluginQuillEditor = dynamic(() => import('@/views/components/plugins/quill-editor'));

/***************************  PLUGINS - QUILL EDITOR  ***************************/

export default function QuillEditor() {
  return <PluginQuillEditor />;
}
