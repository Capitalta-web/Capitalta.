// @next
import dynamic from 'next/dynamic';

// @project
const PluginDropzone = dynamic(() => import('@/views/components/plugins/dropzone'));

/***************************  PLUGINS - DROPZONE  ***************************/

export default function Dropzone() {
  return <PluginDropzone />;
}
