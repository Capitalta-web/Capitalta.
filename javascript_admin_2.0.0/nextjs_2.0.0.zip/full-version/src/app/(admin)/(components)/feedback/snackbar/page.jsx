// @next
import dynamic from 'next/dynamic';

// @project
const FeedbackSnackbar = dynamic(() => import('@/views/components/feedback/snackbar'));

/***************************  FEEDBACK - SNACKBAR  ***************************/

export default function Snackbar() {
  return <FeedbackSnackbar />;
}
