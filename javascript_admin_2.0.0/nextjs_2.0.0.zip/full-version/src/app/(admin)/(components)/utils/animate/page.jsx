import Animate from '@/views/components/utils/animate';

export default function AnimatePage() {
  return <Animate />;
}
