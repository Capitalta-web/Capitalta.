import PropTypes from 'prop-types';

/***************************  LAYOUT - COMPONENTS  ***************************/

export default function Layout({ children }) {
  return <>{children}</>;
}

Layout.propTypes = { children: PropTypes.any };
