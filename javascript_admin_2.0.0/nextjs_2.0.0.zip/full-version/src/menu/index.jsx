// @project
import pages from './pages';
import manage from './manage';
import other from './other';
import plugins from './plugins';
import uiElements from './ui-elements';

/***************************  MENU ITEMS  ***************************/

const menuItems = {
  items: [manage, uiElements, plugins, pages, other]
};

export default menuItems;
