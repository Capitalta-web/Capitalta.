export const profiles = [
  {
    id: '1',
    avatar: '/assets/images/users/avatar-1.png',
    firstName: 'Stacy',
    lastName: 'Reichel',
    username: 'stacy_reichel89',
    email: 's.reichel@saasable.io',
    contact: '212-555-0199',
    dialCode: '+36'
  },
  {
    id: '2',
    avatar: '/assets/images/users/avatar-2.png',
    firstName: 'Morris',
    lastName: 'VonRueden',
    username: 'morrisvvonrued',
    email: 'm.vonrueden99@saasable.io',
    contact: '310-555-0147',
    dialCode: '+36'
  },
  {
    id: '3',
    avatar: '/assets/images/users/avatar-3.png',
    firstName: 'Terri',
    lastName: 'Howe',
    username: 'thehowe123456',
    email: 'terri.howe123@saasable.io',
    contact: '718-555-0193',
    dialCode: '+36'
  },
  {
    id: '4',
    avatar: '/assets/images/users/avatar-4.png',
    firstName: 'Blake',
    lastName: 'Adams',
    username: 'blake_adams007',
    email: 'b.adams@saasable.io',
    contact: '415-555-0138',
    dialCode: '+36'
  },
  {
    id: '5',
    avatar: '/assets/images/users/avatar-5.png',
    firstName: 'Joel',
    lastName: 'Stroman',
    username: 'joelstroman2024',
    email: 'joelstroman@saasable.io',
    contact: '602-555-0176',
    dialCode: '+36'
  },
  {
    id: '6',
    avatar: '/assets/images/users/avatar-4.png',
    firstName: 'Eva',
    lastName: 'Reilly',
    username: 'eva_reilly2023',
    email: 'eva.reilly@hotmail.com',
    contact: '997-555-0127',
    dialCode: '+36'
  },
  {
    id: '7',
    avatar: '/assets/images/users/avatar-3.png',
    firstName: 'Lila',
    lastName: 'Kuhic',
    username: 'lilakuhic_321',
    email: 'lila_kuhic@saasable.io',
    contact: '312-555-0164',
    dialCode: '+36'
  },
  {
    id: '8',
    avatar: '/assets/images/users/avatar-5.png',
    firstName: 'Osvaldo',
    lastName: 'Conn',
    username: 'osvaldoconn_12',
    email: 'osvaldo.conn@gmail.com',
    contact: '213-555-0192',
    dialCode: '+36'
  },
  {
    id: '9',
    avatar: '/assets/images/users/avatar-1.png',
    firstName: 'Dora',
    lastName: 'Heidenreich',
    username: 'dora_heidenreich',
    email: 'd.heidenreich@saasable.io',
    contact: '718-555-0185',
    dialCode: '+36'
  },
  {
    id: '10',
    avatar: '/assets/images/users/avatar-2.png',
    firstName: 'Maya',
    lastName: 'Tran',
    username: 'mayatran_official',
    email: 'maya.tran23@saasable.io',
    contact: '505-555-0190',
    dialCode: '+36'
  },
  {
    id: '11',
    avatar: '/assets/images/users/avatar-3.png',
    firstName: 'Liam',
    lastName: 'Garcia',
    username: 'liamgarcia_007',
    email: 'liam_garcia@saasable.io',
    contact: '606-555-0111',
    dialCode: '+36'
  },
  {
    id: '12',
    avatar: '/assets/images/users/avatar-1.png',
    firstName: 'Nina',
    lastName: 'Patel',
    username: 'ninapatel_xyz',
    email: 'nina.patel001@saasable.io',
    contact: '707-555-0122',
    dialCode: '+36'
  },
  {
    id: '13',
    avatar: '/assets/images/users/avatar-2.png',
    firstName: 'Omar',
    lastName: 'Lopez',
    username: 'omarlopez999',
    email: 'omarlopez@saasable.io',
    contact: '808-555-0133',
    dialCode: '+36'
  },
  {
    id: '14',
    avatar: '/assets/images/users/avatar-5.png',
    firstName: 'Sofia',
    lastName: 'Kim',
    username: 'sofiakim_1234',
    email: 's.kim@saasable.io',
    contact: '909-555-0144',
    dialCode: '+36'
  },
  {
    id: '15',
    avatar: '/assets/images/users/avatar-4.png',
    firstName: 'Ethan',
    lastName: 'Brooks',
    username: 'ethanbrooks55',
    email: 'ethan.brooks@outlook.com',
    contact: '100-555-0155',
    dialCode: '+36'
  },
  {
    id: '16',
    avatar: '/assets/images/users/avatar-1.png',
    firstName: 'Chloe',
    lastName: 'Murphy',
    username: 'chloemurphy444',
    email: 'chloe.murphy23@saasable.io',
    contact: '111-555-0166',
    dialCode: '+36'
  },
  {
    id: '17',
    avatar: '/assets/images/users/avatar-2.png',
    firstName: 'Jason',
    lastName: 'Cruz',
    username: 'jasoncruz_2025',
    email: 'jason.cruz@saasable.io',
    contact: '222-555-0177',
    dialCode: '+36'
  },
  {
    id: '18',
    avatar: '/assets/images/users/avatar-3.png',
    firstName: 'Ava',
    lastName: 'Morgan',
    username: 'avamorgan_off',
    email: 'ava.morgan@saasable.com',
    contact: '333-555-0188',
    dialCode: '+36'
  },
  {
    id: '19',
    avatar: '/assets/images/users/avatar-4.png',
    firstName: 'Noah',
    lastName: 'Reed',
    username: 'noahreed_abc12',
    email: 'nreed@saasable.io',
    contact: '444-555-0199',
    dialCode: '+36'
  },
  {
    id: '20',
    avatar: '/assets/images/users/avatar-5.png',
    firstName: 'Mia',
    lastName: 'Scott',
    username: 'miascott_xyz99',
    email: 'mia.scott@company.com',
    contact: '555-555-0110',
    dialCode: '+36'
  },
  {
    id: '21',
    avatar: '/assets/images/users/avatar-3.png',
    firstName: 'Lucas',
    lastName: 'Young',
    username: 'lucasyoung_123',
    email: 'lucas.young@saasable.io',
    contact: '666-555-0121',
    dialCode: '+36'
  },
  {
    id: '22',
    avatar: '/assets/images/users/avatar-2.png',
    firstName: 'Ella',
    lastName: 'Evans',
    username: 'ellaevans_007',
    email: 'ella.evans@hotmail.com',
    contact: '777-555-0132',
    dialCode: '+36'
  },
  {
    id: '23',
    avatar: '/assets/images/users/avatar-1.png',
    firstName: 'Caleb',
    lastName: 'Turner',
    username: 'calebturner321',
    email: 'caleb.turner@saasable.io',
    contact: '888-555-0143',
    dialCode: '+36'
  },
  {
    id: '24',
    avatar: '/assets/images/users/avatar-5.png',
    firstName: 'Grace',
    lastName: 'Parker',
    username: 'graceparker777',
    email: 'grace.parker@saasable.io',
    contact: '999-555-0154',
    dialCode: '+36'
  },
  {
    id: '25',
    avatar: '/assets/images/users/avatar-4.png',
    firstName: 'Eli',
    lastName: 'Foster',
    username: 'elifoster_555',
    email: 'eli.foster@saasable.io',
    contact: '101-555-0165',
    dialCode: '+36'
  }
];
