export const features = [
  { id: 'FEATURE_1', name: 'Users' },
  { id: 'FEATURE_2', name: 'API Access' },
  { id: 'FEATURE_3', name: 'Priority Support' }
];

export const plans = [
  {
    id: 'PLAN_1',
    title: 'Basic',
    features: [
      { id: 'FEATURE_1', value: '1 User' },
      { id: 'FEATURE_3', value: 'Email Support' }
    ]
  },
  {
    id: 'PLAN_2',
    title: 'Standard',
    features: [
      { id: 'FEATURE_1', value: '25 User' },
      { id: 'FEATURE_2', value: 'Standard API Access' },
      { id: 'FEATURE_3', value: 'Live Chat Support' }
    ]
  },
  {
    id: 'PLAN_3',
    title: 'Enterprise',
    features: [
      { id: 'FEATURE_1', value: 'Unlimited Users' },
      { id: 'FEATURE_2', value: 'Advanced API Access' },
      { id: 'FEATURE_3', value: '24/7 Dedicated Support' }
    ]
  }
];
