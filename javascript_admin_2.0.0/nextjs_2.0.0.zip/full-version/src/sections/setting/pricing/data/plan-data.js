export const pricingModals = [
  { title: 'Flat Rate', value: 'flatRate' },
  { title: 'Tiered', value: 'tiered' },
  { title: 'Pay as You Go', value: 'payAsYouGo' },
  { title: 'Freemium', value: 'freemium' },
  { title: 'Lifetime', value: 'lifetime' },
  { title: 'Subscription', value: 'subscription' },
  { title: 'Custom Pricing', value: 'custom' },
  { title: 'Bundled', value: 'bundled' },
  { title: 'Per User', value: 'perUser' },
  { title: 'Feature Based', value: 'featureBased' }
];

export const billingPeriodsOptions = [
  { title: 'Monthly', value: 'monthly' },
  { title: 'Quarterly', value: 'quarterly' },
  { title: 'Yearly', value: 'yearly' }
];

export const pricingPlanData = [
  {
    id: 'PLAN_1',
    name: 'Basic',
    description: 'Perfect for individuals getting started',
    isRecommended: true,
    priceModal: 'flatRate',
    pricingOptions: [
      { period: 'monthly', price: 20 },
      { period: 'quarterly', price: 30 },
      { period: 'yearly', price: 80 }
    ],
    yearlyDiscount: 3,
    trialPeriodDays: 0,
    features: [
      { id: 'FEATURE_1', value: '1 User', link: '' },
      { id: 'FEATURE_3', value: 'Email Support', link: '' }
    ],
    users: [
      { id: '1', name: 'Terri Howe', photo: '/assets/images/users/avatar-1.png' },
      { id: '2', name: 'Morris VonRueden', photo: '/assets/images/users/avatar-2.png' },
      { id: '3', name: 'Terri Howe', photo: '/assets/images/users/avatar-3.png' },
      { id: '4', name: 'Morris VonRueden', photo: '/assets/images/users/avatar-4.png' },
      { id: '5', name: 'Joel Stroman', photo: '/assets/images/users/avatar-5.png' },
      { id: '6', name: 'Blake Adams', photo: '/assets/images/users/avatar-2.png' }
    ],
    isDraft: true
  },
  {
    id: 'PLAN_2',
    name: 'Standard',
    description: 'Full access to all premium features',
    isRecommended: false,
    priceModal: 'flatRate',
    pricingOptions: [
      { period: 'monthly', price: 30 },
      { period: 'yearly', price: 100 }
    ],
    yearlyDiscount: 5,
    trialPeriodDays: 7,
    features: [
      { id: 'FEATURE_1', value: '25 User', link: '' },
      { id: 'FEATURE_2', value: 'Standard API Access', link: '' },
      { id: 'FEATURE_3', value: 'Live Chat Support', link: '' }
    ],
    users: [
      { id: '1', name: 'Stacy Reichel', photo: '/assets/images/users/avatar-1.png' },
      { id: '2', name: 'Terri Howe', photo: '/assets/images/users/avatar-2.png' },
      { id: '3', name: 'Morris VonRueden', photo: '/assets/images/users/avatar-3.png' }
    ],
    isDraft: true
  },
  {
    id: 'PLAN_3',
    name: 'Enterprise',
    description: 'Scalable solution for large teams',
    isRecommended: false,
    priceModal: 'flatRate',
    pricingOptions: [
      { period: 'monthly', price: 40 },
      { period: 'yearly', price: 120 }
    ],
    yearlyDiscount: 5,
    trialPeriodDays: 7,
    features: [
      { id: 'FEATURE_1', value: 'Unlimited Users', link: '' },
      { id: 'FEATURE_2', value: 'Advanced API Access', link: '' },
      { id: 'FEATURE_3', value: '24/7 Dedicated Support', link: '' }
    ],
    users: [
      { id: '1', name: 'Stacy Reichel', photo: '/assets/images/users/avatar-1.png' },
      { id: '2', name: 'Terri Howe', photo: '/assets/images/users/avatar-2.png' },
      { id: '3', name: 'Morris VonRueden', photo: '/assets/images/users/avatar-3.png' }
    ],
    isDraft: false
  }
];
