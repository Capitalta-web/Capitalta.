export let Plans;

(function (Plans) {
  Plans['BASIC'] = 'Basic';
  Plans['STARTER'] = 'Starter';
  Plans['ENTERPRISE'] = 'Enterprise';
})(Plans || (Plans = {}));

export let BillingStatus;

(function (BillingStatus) {
  BillingStatus['PAID'] = 'Paid';
  BillingStatus['SCHEDULED'] = 'Scheduled';
})(BillingStatus || (BillingStatus = {}));

export let BillingCycle;

(function (BillingCycle) {
  BillingCycle['MONTHLY'] = 'Monthly';
  BillingCycle['YEARLY'] = 'Yearly';
})(BillingCycle || (BillingCycle = {}));
