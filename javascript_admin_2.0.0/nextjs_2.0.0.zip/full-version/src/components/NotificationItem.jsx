'use client';
import PropTypes from 'prop-types';

import { isValidElement } from 'react';

// @mui
import { useTheme } from '@mui/material/styles';
import Avatar from '@mui/material/Avatar';
import Badge from '@mui/material/Badge';
import Stack from '@mui/material/Stack';
import Typography from '@mui/material/Typography';
import Box from '@mui/material/Box';

// @project
import { AvatarSize } from '@/enum';

/***************************  NOTIFICATION - LIST  ***************************/

export default function NotificationItem({ avatar, badgeAvatar, title, subTitle, dateTime, isSeen = false }) {
  const theme = useTheme();
  const ellipsis = { textOverflow: 'ellipsis', overflow: 'hidden', whiteSpace: 'nowrap' };

  const avatarContent = isValidElement(avatar) ? <Avatar color="default">{avatar}</Avatar> : <Avatar {...avatar} />;

  return (
    <Stack direction="row" sx={{ width: 1, alignItems: 'center', justifyContent: 'space-between', gap: 1 }}>
      <Stack direction="row" sx={{ alignItems: 'center', gap: 1.25, flexShrink: 0 }}>
        {badgeAvatar ? (
          // Box component for badge position due to parent Stack component
          <Box>
            <Badge
              overlap="circular"
              anchorOrigin={{ vertical: 'bottom', horizontal: 'right' }}
              badgeContent={
                <Avatar
                  color="default"
                  size={AvatarSize.BADGE}
                  sx={{ border: `1px solid`, borderColor: 'common.white', ...theme.applyStyles('dark', { borderColor: 'common.black' }) }}
                  {...badgeAvatar}
                />
              }
              slotProps={{ badge: { sx: { bottom: '22%' } } }}
            >
              {avatarContent}
            </Badge>
          </Box>
        ) : (
          avatarContent
        )}
      </Stack>
      {/* minWidth: 0 -> Critical to ensure ellipsis works */}
      <Stack sx={{ flexGrow: 1, minWidth: 0, maxWidth: 1, gap: 0.25 }}>
        <Typography variant={isSeen ? 'body2' : 'subtitle2'} {...(isSeen && { color: 'grey.700' })} noWrap sx={ellipsis}>
          {title}
        </Typography>
        {subTitle && (
          <Typography variant="caption" color="text.secondary" noWrap sx={ellipsis}>
            {subTitle}
          </Typography>
        )}
      </Stack>
      {dateTime && (
        <Typography variant="caption" sx={{ marginLeft: 'auto', flexShrink: 0 }} {...(isSeen && { color: 'grey.700' })}>
          {dateTime}
        </Typography>
      )}
    </Stack>
  );
}

NotificationItem.propTypes = {
  avatar: PropTypes.any,
  badgeAvatar: PropTypes.any,
  title: PropTypes.any,
  subTitle: PropTypes.any,
  dateTime: PropTypes.any,
  isSeen: PropTypes.bool
};
